package com.example.co2monitor;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

//Packages used for Firebase

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    // Public and Private members used in MainActivity/
    private static final String TAG = "MyActivity";
    private static int [] array = new int[10];       //used in myThread1
    private static int [] array_g = new int [10]; //Used in thread 2 to hold sensor readings every 5 sec
    private static Queue<Integer> q_graph = new LinkedBlockingQueue<>(360);  //Queue holding averaged data, averaged every 30 seconds
    public Graph_util guObj = new Graph_util();


    private TextView co2lable;
    private TextView humidityLable;
    private TextView tempLable;

    private TextView co2Levels;
    private TextView temperature;
    private TextView humidity;

    private Button suggestion;
    private Button info;
    private Button realButton;


    DatabaseReference connectedRef = FirebaseDatabase.getInstance().getReference(".info/connected");    //Firebase ref to check App connection to firebase
    DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();    //Firebase references
    DatabaseReference co2data = mDatabase.child("co2_ppm");
    DatabaseReference tempData = mDatabase.child("temperature");
    DatabaseReference humidityData = mDatabase.child("humidity");

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;

    //Methods:
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        /*------Hooks------*/
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        /*-------ToolBar------*/

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        /*------NavigationMenu------*/



        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(MainActivity.this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        //
        co2lable = findViewById(R.id.label);//Indicates that the numbers below are CO2 ppms
        humidityLable = findViewById(R.id.humidityLabletextView);
        tempLable = findViewById(R.id.tempLableTextView);

        co2Levels = findViewById(R.id.realButton);//Used to show ppm
        temperature = findViewById(R.id.tempTextView);
        humidity = findViewById(R.id.humidityTextView);




    }

    //Method to open realButton Dialog
    public void openDialog() {
        RealDialog realDialog = new RealDialog();
        realDialog.show(getSupportFragmentManager(), "real dialog");

    }



    @Override
    public void onBackPressed() {

        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();

        }

    }

    //Method used to go to the suggestion activity
    public void openSuggestionActivity() {
        Intent intent = new Intent(this, SuggestionActivity.class);
        startActivity(intent);
    }

    //Method used to go to the info activity
    public void openInfoActivity() {
        Intent intent = new Intent(this, InfoActivity.class);
        startActivity(intent);

    }

    public void openAboutActivity() {
        Intent intent = new Intent(this, About.class);
        startActivity(intent);
    }

    public void openSettingsActivity() {
        Intent intent = new Intent(this, Settings.class);
        startActivity(intent);
    }

    /*public static Queue<Integer> getQ_graph() {
        return q_graph;
    }*/


    //Thread1 running with a while loop to check the connection between sensor and the app every 40 seconds
    Runnable myRunnable = new Runnable(){
        short counter = 0;
        @Override
        public void run(){
            while(counter <= 9){            //sample 5 sensor readings

                try {
                    Thread.sleep(10000);    //sample sensor reading every 10 seconds
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                co2data.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String sensor_data = dataSnapshot.getValue(String.class);
                        int data_int = Integer.parseInt(sensor_data);
                        Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++"+counter);
                        array[counter] = data_int;
                        Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++"+array[counter]);
                        if (counter == 9){
                            counter=0;
                            int sum = 0;
                            for (int value : array) {
                                sum = sum + value;
                            }
                            int average = sum/array.length;        //Average readings
                            Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++"+average);
                            if (average == array[0] && average == array[1] && average==array[2] && average ==array[3]&&average==array[4]){    //Check if readings are the same
                                Toast.makeText(MainActivity.this, "Data is out of sync, Check connection!",
                                        Toast.LENGTH_LONG).show();
                                co2Levels.setText("Loading...");
                                temperature.setText("Loading");
                                humidity.setText("Loading");

                            }
                        }
                        else{
                            counter = (short) (counter + 1);
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


            }
        }
    };





    //Thread 2 for GRAPHING data
    /* Runnable myRunnable2 = new Runnable(){
   short counter2= 0;
        @Override
        public void run(){
                while(counter2 <= 5){
                    try {
                        Thread.sleep(5000);     //sample sensor readings every 5 seconds for graphing
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                        co2data.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String co2data2 = dataSnapshot.getValue(String.class);
                                int co2data_int = Integer.parseInt(co2data2);

                                array_g[counter2] = co2data_int;
                                //Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++"+counter2);
                                if (counter2 == 5){
                                    int sum =0;
                                    for(int v:array_g){
                                        sum = sum + v;
                                    }
                                    int average = sum/array_g.length;
                                    //Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++"+average);

                                    guObj.q_graph.add(average);     //Add the average to queue
                                    int p = guObj.q_graph.peek();
                                    //Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++" + p);
                                       // Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++"+q_graph.size());

                                }
                                else{
                                    counter2 = (short) (counter2 + 1);
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });

                }
            }
    };*/

    // CO2 ppm will be shown with onStart after onCreate is called
    @Override
    protected void onStart() {
        super.onStart();
        Thread myThread = new Thread(myRunnable);
        //Thread myThread2 = new Thread(myRunnable2);
        myThread.start();
        // myThread2.start();

        co2data.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String co2data = dataSnapshot.getValue(String.class);
                co2Levels.setText(co2data);
            /*if (Integer.parseInt(co2data) < 401) {
                    co2Levels.setTextColor(Color.parseColor("#99CC00"));
                } else if (Integer.parseInt(co2data) < 1001) {
                    co2Levels.setTextColor(Color.parseColor("#669900"));
                } else if (Integer.parseInt(co2data) < 2001) {
                    co2Levels.setTextColor(Color.parseColor("FFBB33"));
                } else if (Integer.parseInt(co2data) < 5000) {
                    co2Levels.setTextColor(Color.parseColor("FF8800"));
                } else {
                    co2Levels.setTextColor(Color.parseColor("CC00000"));
                }*/

                if (Integer.parseInt(co2data) < 401) {

                    realButton = findViewById(R.id.realButton);
                    realButton.setOnClickListener(new View.OnClickListener() {


                        @Override
                        public void onClick(View view) {

                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                            builder.setTitle("250-400ppm");
                            builder.setMessage("Normal background concentration in outdoor ambient air.");

                            builder.setPositiveButton("Got it!", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();

                                }
                            });
                            builder.show();


                        }

                    });


                } else if (Integer.parseInt(co2data) < 1001) {

                    realButton = findViewById(R.id.realButton);
                    realButton.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View view) {

                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                            builder.setTitle("400-1000ppm");
                            builder.setMessage("Typical concentration level of occupied indoor spaces with good air exchange.");

                            builder.setPositiveButton("Got it!", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();

                                }
                            });
                            builder.show();


                        }
                    });


                } else if (Integer.parseInt(co2data) < 2001) {

                    realButton = findViewById(R.id.realButton);
                    realButton.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View view) {

                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                            builder.setTitle("1000-2000ppm");
                            builder.setMessage("Level associated with complaints of drowsiness and poor air.");

                            builder.setPositiveButton("Got it!", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();

                                }
                            });
                            builder.show();


                        }
                    });


                } else if (Integer.parseInt(co2data) < 5000) {

                    realButton = findViewById(R.id.realButton);
                    realButton.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View view) {

                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                            builder.setTitle("2000-5000ppm");
                            builder.setMessage("Headaches, sleepiness and stagnant, stale, stuffy air. Poor " +
                                    " concentration, loss of attention, increased heart rate and slight nausea may also be " +
                                    " present.");

                            builder.setPositiveButton("Got it!", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();

                                }
                            });
                            builder.show();


                        }
                    });


                } else {


                    realButton = findViewById(R.id.realButton);
                    realButton.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View view) {

                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                            builder.setTitle("5000ppm");
                            builder.setMessage(" Indication of unusual air conditions where high levels of other gases could also" +
                                    " be present. Toxicity or oxygen deprivation could occur. This is the permissible exposure " +
                                    " limit for daily workplace exposures. It is recommended that the average concentration over " +
                                    " an 8-hour period should not exceed 5,000 ppm.");

                            builder.setPositiveButton("Got it!", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();


                                }
                            });
                            builder.show();


                        }
                    });


                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

      /*  co2data.addValueEventListener(new ValueEventListener() {
            short counter = 0;
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String sensor_data = dataSnapshot.getValue(String.class);
                int data_int = Integer.parseInt(sensor_data);
                if (counter <= 9)
                Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++"+counter);
                array[counter] = data_int;
                Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++"+array[counter]);
                if (counter == 9){
                    counter=0;
                    int sum = 0;
                    for (int value : array) {
                        sum = sum + value;
                    }
                    int average = sum/array.length;        //Average readings
                    Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++"+average);
                    if (average == array[0] && average == array[1] && average==array[2] && average ==array[3]&&average==array[4]){    //Check if readings are the same
                        Toast.makeText(MainActivity.this, "Data is out of sync, Check connection!",
                                Toast.LENGTH_LONG).show();
                        co2Levels.setText("Loading...");
                        temperature.setText("Loading");
                        humidity.setText("Loading");

                    }
                }
                else{
                    counter = (short) (counter + 1);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });*/


        co2data.addValueEventListener(new ValueEventListener() {
            short counter2=0;
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String co2data2 = dataSnapshot.getValue(String.class);
                int co2data_int = Integer.parseInt(co2data2);
                if (counter2 <= 9) {
                    array_g[counter2] = co2data_int;
                    //Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++" + counter2);
                    // Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++" + array_g[counter2]);
                    if (counter2 == 9) {
                        counter2 = 0;
                        int sum = 0;
                        for (int v : array_g) {
                            sum = sum + v;
                        }
                        int average = sum / array_g.length;
                        //Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++" + average);

                        q_graph.add(average);     //Add the average to queue
                        int p = q_graph.peek();
                        //Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++" + p);
                        //Log.d(TAG, "MESSAGE*____________+++++++++++++++++++++++++++++++++++"+q_graph.size());

                    } else {
                        counter2 = (short) (counter2 + 1);
                    }

                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        tempData.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String temp = dataSnapshot.getValue(String.class);
                temperature.setText(temp + " ˚C");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        humidityData.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String hum = dataSnapshot.getValue(String.class);
                humidity.setText(hum + " %");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        connectedRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean connected = snapshot.getValue(Boolean.class);
                if (connected) {
                    Log.d(TAG, "connected");
                    Toast.makeText(MainActivity.this, "Wifi connected ",
                            Toast.LENGTH_LONG).show();
                } else {
                    Log.d(TAG, "Wifi not connected");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w(TAG, "Listener was cancelled");
            }
        });


    }



    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.nav_home:
                break;
            case R.id.nav_tips:
                Intent i1 = new Intent(MainActivity.this, SuggestionActivity.class);
                startActivity(i1);
                break;
            case R.id.nav_info:
                Intent i2 = new Intent(MainActivity.this, InfoActivity.class);
                startActivity(i2);
                break;
            case R.id.install_info:
                Intent i4 = new Intent(MainActivity.this, InstallActivity.class);
                startActivity(i4);
                break;

        }



        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}